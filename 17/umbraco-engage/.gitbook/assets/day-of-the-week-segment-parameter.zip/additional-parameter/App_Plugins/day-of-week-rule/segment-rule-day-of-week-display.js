﻿angular.module("umbraco").component("segmentRuleDayOfWeekDisplay", {
    templateUrl: "/App_Plugins/day-of-week-rule/segment-rule-day-of-week-display.html",
    bindings: {
        config: "<",
        rule: "<",
    },
});
