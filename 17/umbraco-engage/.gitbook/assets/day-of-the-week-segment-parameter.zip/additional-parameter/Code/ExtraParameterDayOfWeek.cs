﻿using Newtonsoft.Json;
using System;
using Umbraco.Engage.Infrastructure.Personalization.PersonalizationProfile;
using Umbraco.Engage.Infrastructure.Personalization.Segments;
using Umbraco.Engage.Infrastructure.Personalization.Segments.Rules;
using Umbraco.Engage.Web.Cockpit.Segments;
using Umbraco.Core;
using Umbraco.Core.Composing;

namespace UmbracoDKDemo.Code
{
    public class TestSegmentRuleComposer : IUserComposer
    {
        public void Compose(Composition composition)
        {
            composition.Register<ISegmentRuleFactory, DayOfWeekSegmentRuleFactory>(Lifetime.Transient);
            composition.Register<ICockpitSegmentRuleFactory, DayOfWeekCockpitSegmentRuleFactory>(Lifetime.Transient);
        }
    }

    public class DayOfWeekSegmentRule : BaseSegmentRule
    {
        public DayOfWeekSegmentRuleConfig TypedConfig { get; }

        public override SegmentRuleValidationMode ValidationMode => SegmentRuleValidationMode.Once;

        public DayOfWeekSegmentRule(long id, long segmentId, string type, string config, bool isNegation, DateTime created, DateTime? updated, DayOfWeekSegmentRuleConfig typedConfig)
            : base(id, segmentId, type, config, isNegation, created, updated)
            => TypedConfig = typedConfig;

        public override bool IsSatisfied(IPersonalizationProfile context)
            => context.Pageview.Timestamp.DayOfWeek == TypedConfig.DayOfWeek;
    }

    public class DayOfWeekSegmentRuleFactory : ISegmentRuleFactory
    {
        public string RuleType { get; } = "DayOfWeek";

        public ISegmentRule CreateRule(string config, bool isNegation, long id, long segmentId, DateTime created, DateTime? updated)
        {
            var typedConfig = JsonConvert.DeserializeObject<DayOfWeekSegmentRuleConfig>(config);
            return new DayOfWeekSegmentRule(id, segmentId, RuleType, config, isNegation, created, updated, typedConfig);
        }
    }

    public class DayOfWeekSegmentRuleConfig
    {
        public DayOfWeek DayOfWeek { get; set; }
    }

    public class DayOfWeekCockpitSegmentRuleFactory : ICockpitSegmentRuleFactory
    {
        public bool TryCreate(ISegmentRule segmentRule, bool isSatisfied, out CockpitSegmentRule cockpitSegmentRule)
        {
            cockpitSegmentRule = null;

            if (segmentRule is DayOfWeekSegmentRule dayOfWeekRule)
            {
                cockpitSegmentRule = new CockpitSegmentRule
                {
                    Name = "Day of week",
                    Icon = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAB2wAAAdsBV+WHHwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAANISURBVHic7Zu/axRBFMc/74gggQhRTIgRlEBIUiUopgmYRkzaIEELsVSUgJV1/oWkEi1FBAuRlFpeZ9BoOkVIGk+JhxEs5JAkz+L2YDO7e7nZu5vZ3N4XHty9me+8Hzf7dmZ2D1UljQALwPtAFtKO49u+BINZQUROAt+B/kD1GzinqhXrwVKglfYLKX2YCRkn+DyTciyv9tMm4ESDunahZfbTJqBjkPsE9CQ1iMhZ4ExC8/k4nYiMt8Sro2Fr/5eqlmNbjFvLBPAC2Aa0w2Q7iG3iUMxB4AI8AioZcLTdUglilXACljLgmGtZUlUEGAU+Ab3kC3+BqR7gAdHg/wDPga8J5HHgnqF7AnxupYd1YGt/FLgNnArpeqnGTpHDU+MfMHzEOnye6JSad7gPsLYPDAexhTnFAjBlZGtNVUuN/hTHBUFMa4Z6qgD0GcqOCz4EM7a+3K8E0yZgE9gLfd8LdK7QMvupEqCqP4DVwPAesBronKDV9s1qumJRjYeAIdenQWntAytmvImboYYy5/BXb5f9bhH07YBvxF0C/Q739a7RbyqEajHILXJ/CXQT4NsB34grgkXgtWtHHGEBuBpWxCXgo6quuPHHLUTkIkYCcn8JdBPg2wHfsE6AiCyLSElE1JCSiCxnnR+HhrfDwGxMf1NmM8yPbIdtZ8ClJvv45sfCZgYMUv/xWQUYzDC/uQMRVd0RkQvAHarn7GGUgGequpNVfuK4NDgDjrvQghrQcegmwLcDvmF9KiwiN4G7xBehp6r6Msv8ONjcBidj+psymWF+00XwepN9fPMjsE3AK+CgTvtB0Cer/AhsF0JbIjIN3Cf6qto34LGqbmWVnziuId2FUJ7QTYBvB3wjzULoMvWL0Ics8+NgsxAaAfZjODXZB0YyzG+6CN6g/mVTCPpklR9LsMHbJvv45kdguxDaFJFb1N+MJL6t5ZufOC4N1oDjLnQXQlEUgF1DN+bDEUcwY9stABuGck5ErjhyyBmCmOYM9UYPsA5cC/cF3onIG+CLI//ajTGqwYuhXwcYAMocfdLSaVIGBmrVcTEDDrmWRVUlfItYzMlMKNeCVzX+PS4iA8BDYJrqQ8bTdAZ2qRb7dapvlv+sNfwHCNoge2U5h7MAAAAASUVORK5CYII=",
                    Config = dayOfWeekRule.TypedConfig.DayOfWeek.ToString(),
                    IsNegation = segmentRule.IsNegation,
                    IsSatisfied = isSatisfied,
                    Type = segmentRule.Type,
                };

                return true;
            }

            return false;
        }
    }
}
